# This file makes the pc_ai_lib folder a Python package.
# Do not delete this file.

from .ai_helpers import get_ai_response
